const common=require('./libs/common');

var str='123456';
var str=common.md5(str+'FDSW$t34tregt5tO&$(#RHuyoyiUYE*&OI$HRLuy87odlfh是个风格热腾腾)');

console.log(str);
