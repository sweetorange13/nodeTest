const pathLib=require('path');

var obj=pathLib.parse('/root/aaa/bbb/1.txt');

console.log(obj);
