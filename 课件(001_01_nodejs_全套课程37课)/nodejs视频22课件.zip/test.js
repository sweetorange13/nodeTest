var str='\
aaa\n\
\n\
asdfasdfasdfafsdasdf\n\
aaa\n\
\n\
asdfasdfasdfafsdasdf\n\
';

console.log(str);
